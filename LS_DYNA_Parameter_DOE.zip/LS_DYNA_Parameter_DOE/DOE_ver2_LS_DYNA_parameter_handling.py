import random
a = [(x, y, z) for x in range(500, 550, 2) for y in range(750, 700, -2) for z in range (90, 40, -2)
     if ((x>540) and (y<712) and (7<52))]
print(a)
print()
b = []
for i in range(10):
    p = random.randint(0, len(a))
    b.append(a[p])
print(b)
l = 1

b = [(546, 702, 88), (548, 710, 72), (546, 710, 54), (542, 706, 42), (548, 706, 50), (542, 710, 66), (544, 704, 50), (548, 702, 66), (546, 710, 54), (542, 702, 86)]
for i in b:
    l +=1
    s, p, q = i
    with open("F:/pythonTimBuchalka/test/PYDOE_ver1.key", 'r') as f_inp:
        with open("F:/pythonTimBuchalka/test/PYDOE_ver{}.key".format(l), 'w') as f_out:
            lines = f_inp.read()
            lines = lines.format(var1=s, var2=p, var3=q)
            f_out.write(lines)


